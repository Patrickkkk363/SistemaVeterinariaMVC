﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using CapaEntidad;

namespace CapaDatos
{
    public class EmpleadoDAO
    {
        private string cadena =
            "Data Source=.\\SQLPATRICK;Initial Catalog=DBVeterinariaPetCare;Integrated Security=True";

        public List<Empleado> Listar()
        {
            List<Empleado> lista = new List<Empleado>();

            using (SqlConnection cn = new SqlConnection(cadena))
            {
                SqlCommand cmd = new SqlCommand("SP_ListarEmpleados", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    lista.Add(new Empleado
                    {
                        IdEmpleado = Convert.ToInt32(dr["IdEmpleado"]),
                        Documento = dr["Documento"].ToString(),
                        Nombre = dr["Nombre"].ToString(),
                        Apellido = dr["Apellido"].ToString(),
                        Correo = dr["Correo"].ToString(),
                        Usuario = dr["Usuario"].ToString(),
                        Estado = Convert.ToBoolean(dr["Estado"]),
                        FechaRegistro = Convert.ToDateTime(dr["FechaRegistro"])
                    });
                }
            }
            return lista;
        }

        public Empleado Obtener(int id)
        {
            Empleado emp = null;

            using (SqlConnection cn = new SqlConnection(cadena))
            {
                SqlCommand cmd = new SqlCommand("SP_MostrarEmpleado", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@IdEmpleado", id);

                cn.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    emp = new Empleado
                    {
                        IdEmpleado = Convert.ToInt32(dr["IdEmpleado"]),
                        Documento = dr["Documento"].ToString(),
                        Nombre = dr["Nombre"].ToString(),
                        Apellido = dr["Apellido"].ToString(),
                        Correo = dr["Correo"].ToString(),
                        Usuario = dr["Usuario"].ToString(),
                        Estado = Convert.ToBoolean(dr["Estado"]),
                        FechaRegistro = Convert.ToDateTime(dr["FechaRegistro"])
                    };
                }
            }
            return emp;
        }

        public void Registrar(Empleado e)
        {
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                SqlCommand cmd = new SqlCommand("SP_RegistrarEmpleado", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Documento", e.Documento);
                cmd.Parameters.AddWithValue("@Nombre", e.Nombre);
                cmd.Parameters.AddWithValue("@Apellido", e.Apellido);
                cmd.Parameters.AddWithValue("@Correo", e.Correo);
                cmd.Parameters.AddWithValue("@Usuario", e.Usuario);
                cmd.Parameters.AddWithValue("@Clave", e.Clave);

                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Editar(Empleado e)
        {
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                SqlCommand cmd = new SqlCommand("SP_EditarEmpleado", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@IdEmpleado", e.IdEmpleado);
                cmd.Parameters.AddWithValue("@Documento", e.Documento);
                cmd.Parameters.AddWithValue("@Nombre", e.Nombre);
                cmd.Parameters.AddWithValue("@Apellido", e.Apellido);
                cmd.Parameters.AddWithValue("@Correo", e.Correo);
                cmd.Parameters.AddWithValue("@Usuario", e.Usuario);
                cmd.Parameters.AddWithValue("@Clave", e.Clave);
                cmd.Parameters.AddWithValue("@Estado", e.Estado);

                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
