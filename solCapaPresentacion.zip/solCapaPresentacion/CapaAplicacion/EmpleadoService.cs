﻿using System.Collections.Generic;
using CapaEntidad;
using CapaDatos;

namespace CapaAplicacion
{
    public class EmpleadoService
    {
        private EmpleadoDAO dao = new EmpleadoDAO();

        public List<Empleado> Listar()
        {
            return dao.Listar();
        }

        public Empleado Obtener(int id)
        {
            return dao.Obtener(id);
        }

        public void Registrar(Empleado e)
        {
            dao.Registrar(e);
        }

        public void Editar(Empleado e)
        {
            dao.Editar(e);
        }
    }
}
