﻿using System.Web.Mvc;
using CapaAplicacion;
using CapaEntidad;

namespace CapaPresentacion.Controllers
{
    public class EmpleadoController : Controller
    {
        private EmpleadoService service = new EmpleadoService();

        public ActionResult Lista()
        {
            var lista = service.Listar();
            return View(lista);
        }

        public ActionResult Insertar()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Insertar(Empleado e)
        {
            if (ModelState.IsValid)
            {
                service.Registrar(e);
                return RedirectToAction("Lista");
            }
            return View(e);
        }

        public ActionResult Editar(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("Lista");
            }

            var emp = service.Obtener(id.Value);

            if (emp == null)
            {
                return RedirectToAction("Lista");
            }

            return View(emp);
        }

        [HttpPost]
        public ActionResult Editar(Empleado e)
        {
            if (ModelState.IsValid)
            {
                service.Editar(e);
                return RedirectToAction("Lista");
            }
            return View(e);
        }
    }
}
